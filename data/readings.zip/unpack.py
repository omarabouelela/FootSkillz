import os
import shutil
import pandas as pd
import numpy as np
import patoolib  # Requires: pip install patool
from glob import glob
import zipfile

# CONFIGURATION
RAR_FILE = r"C:\Users\omar1\Downloads\readings.rar"
EXTRACT_PATH = './extracted_data'
PAUSE_THRESHOLD_STD = 0.5  # Acceleration variance threshold for "stillness"
PAUSE_DURATION_S = 0.5     # Minimum seconds of stillness required at start
SAMPLING_RATE_HZ = 50      # Approximate Hz of your sensors (adjust if known)

def analyze_reading(zip_path):
    """Deeply analyzes a single reading (ZIP) for quality."""
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            # 1. Validation: Check if required files exist
            file_list = z.namelist()
            required = ['Accelerometer.csv', 'Gyroscope.csv', 'Gravity.csv']
            if not all(f in file_list for f in required):
                return False, "Missing sensor CSVs"

            # 2. Analysis: Load Accelerometer data
            with z.open('Accelerometer.csv') as f:
                df = pd.read_csv(f)
                
            # Check for empty data
            if df.empty:
                return False, "Empty Dataframe"
                
            # Combine axes for magnitude analysis
            # Assuming columns are typically 'x', 'y', 'z' or similar
            # Adjust column names based on your actual CSV headers
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) < 3:
                 return False, "Invalid CSV columns"
            
            # Calculate Magnitude: sqrt(x^2 + y^2 + z^2)
            df['mag'] = np.sqrt(df[numeric_cols[0]]**2 + df[numeric_cols[1]]**2 + df[numeric_cols[2]]**2)
            
            # 3. Validation: Pause Detection
            # We check the first N samples for stillness
            samples_to_check = int(PAUSE_DURATION_S * SAMPLING_RATE_HZ)
            if len(df) < samples_to_check:
                return False, "Recording too short (< 0.5s)"
                
            initial_window = df['mag'].iloc[:samples_to_check]
            initial_std = initial_window.std()
            
            # If variance is high at the very start, user was already moving
            if initial_std > PAUSE_THRESHOLD_STD:
                return False, f"No Pause Detected (Start Variance: {initial_std:.2f})"
                
            return True, "Good Data"

    except Exception as e:
        return False, f"Corrupt File or Error: {str(e)}"

def main():
    # 1. Extract RAR
    if not os.path.exists(EXTRACT_PATH):
        os.makedirs(EXTRACT_PATH)
    
    print(f"Extracting {RAR_FILE}...")
    try:
        patoolib.extract_archive(RAR_FILE, outdir=EXTRACT_PATH, verbosity=-1)
    except Exception as e:
        print(f"Error extracting RAR: {e}")
        return

    # 2. Iterate through folders (Skills) and ZIPs (Readings)
    report = []
    
    # Walk through the extracted structure
    for root, dirs, files in os.walk(EXTRACT_PATH):
        for file in files:
            if file.lower().endswith(".zip"):
                full_path = os.path.join(root, file)
                # Get skill name from parent folder
                skill_name = os.path.basename(root)
                
                is_good, reason = analyze_reading(full_path)
                
                status = "GOOD" if is_good else "BAD"
                report.append({
                    "Skill": skill_name,
                    "File": file,
                    "Status": status,
                    "Reason": reason
                })

    # 3. Output Results
    results_df = pd.DataFrame(report)
    print("\nanalysis Complete. Summary:")
    print(results_df['Status'].value_counts())
    
    print("\n=== BAD READINGS (Action Required) ===")
    bad_readings = results_df[results_df['Status'] == 'BAD']
    if bad_readings.empty:
        print("None! All data looks good.")
    else:
        print(bad_readings[['Skill', 'File', 'Reason']].to_string(index=False))

if __name__ == "__main__":
    main()